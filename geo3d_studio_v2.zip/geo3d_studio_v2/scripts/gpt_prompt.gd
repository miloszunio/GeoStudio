class_name GptPrompt
extends RefCounted
## Builds the text for ChatGPT that turns reference photos into ONE texture sheet for the model.
## Fixed layout: 4096 x 4096 px, two columns x four rows of 2048 x 1024 px sectors, one wall per sector,
## so the program (and a human) always know what is where. Dimensions come from the EGiB footprint.
##
## info: {
##   "name": String, "place": String,
##   "floors": int, "kind": String (EGiB code or ""), "roof": "gable"|"flat"|"shed",
##   "main": {"len": m (along the ridge / long side), "wid": m, "wall_h": m, "roof_h": m},
##   "annexes": [{"len": m, "wid": m, "wall_h": m}],
## }

const SECTOR := Vector2i(2048, 1024)


static func fit_px(w_m: float, h_m: float) -> Vector2i:
	## size in px of a w x h metre wall fitted into one sector with exact proportions
	var k := minf(float(SECTOR.x) / maxf(w_m, 0.1), float(SECTOR.y) / maxf(h_m, 0.1))
	return Vector2i(int(round(w_m * k)), int(round(h_m * k)))


## Elements of the sheet as [code, width m, height m]: what has to fit into the sectors.
static func elements(info: Dictionary) -> Array:
	var main: Dictionary = info.get("main", {})
	var len_m := float(main.get("len", 10.0))
	var wid_m := float(main.get("wid", 6.0))
	var wall_h := float(main.get("wall_h", 3.0))
	var roof_h := float(main.get("roof_h", 0.0))
	var gable_h := wall_h + (roof_h if str(info.get("roof", "gable")) == "gable" else 0.0)
	var out: Array = [["S1", len_m, wall_h], ["S2", len_m, wall_h], ["S3", wid_m, gable_h], ["S4", wid_m, gable_h],
		["S5", len_m, _slope(info)]]
	var idx := 6
	for a in info.get("annexes", []):
		if idx > 8:
			break
		out.append(["S%d" % idx, float(a.get("len", 4.0)), float(a.get("wall_h", 3.0))])
		idx += 1
	return out


static func _slope(info: Dictionary) -> float:
	var main: Dictionary = info.get("main", {})
	var wid_m := float(main.get("wid", 6.0))
	if str(info.get("roof", "gable")) != "gable":
		return wid_m
	return sqrt(pow(wid_m * 0.5, 2.0) + pow(float(main.get("roof_h", 0.0)), 2.0))


## One scale for the whole sheet: the largest whole number of px per metre at which every element
## still fits its 2048 x 1024 sector (minus a 16 px margin). Walls drawn at this scale keep their
## real proportions and the same brick is the same size everywhere.
static func scale_px_per_m(info: Dictionary) -> int:
	var k := 1e9
	for e in elements(info):
		k = minf(k, minf(float(SECTOR.x - 32) / maxf(float(e[1]), 0.1), float(SECTOR.y - 32) / maxf(float(e[2]), 0.1)))
	return maxi(int(floor(k)), 1)


static func _wall_line(code: String, title: String, w: float, h: float, ppm: int, extra := "") -> String:
	return "- %s – %s: %.1f m × %.1f m, czyli %d × %d px (proporcje %.2f : 1); umieść w lewym górnym rogu sektora, 16 px od krawędzi.%s" % [
		code, title, w, h, int(round(w * ppm)), int(round(h * ppm)), w / maxf(h, 0.1), extra]


static func build(info: Dictionary) -> String:
	var main: Dictionary = info.get("main", {})
	var len_m := float(main.get("len", 10.0))
	var wid_m := float(main.get("wid", 6.0))
	var wall_h := float(main.get("wall_h", 3.0))
	var roof_h := float(main.get("roof_h", 0.0))
	var roof_kind := str(info.get("roof", "gable"))
	var annexes: Array = info.get("annexes", [])
	var ppm := scale_px_per_m(info)

	var l: Array[String] = []
	l.append("Zrób z załączonych zdjęć JEDEN arkusz tekstur budynku do modelu 3D. Wynik: obraz kwadratowy 4096 × 4096 px.")
	l.append("")
	l.append("BUDYNEK (dane z ewidencji gruntów i budynków)")
	if str(info.get("name", "")) != "":
		l.append("- nazwa projektu: %s" % info["name"])
	if str(info.get("place", "")) != "":
		l.append("- położenie: %s" % info["place"])
	l.append("- obrys głównej bryły: %.1f × %.1f m, wysokość ścian do okapu %.1f m%s" % [
		len_m, wid_m, wall_h, (", kondygnacje nadziemne: %d" % int(info["floors"])) if int(info.get("floors", 0)) > 0 else ""])
	match roof_kind:
		"flat":
			l.append("- dach płaski")
		"shed":
			l.append("- dach pulpitowy")
		_:
			l.append("- dach dwuspadowy, wzniesienie kalenicy %.1f m nad okapem, kalenica wzdłuż boku %.1f m (ściany równoległe do kalenicy = „długie”)" % [roof_h, len_m])
	if not annexes.is_empty():
		l.append("- dobudówki: %d" % annexes.size())
	if str(info.get("kind", "")) != "":
		l.append("- rodzaj wg ewidencji (KST): %s" % info["kind"])
	l.append("")
	l.append("UKŁAD ARKUSZA – płótno 4096 × 4096 px podzielone na 8 sektorów po 2048 × 1024 px (2 kolumny, 4 rzędy). W każdym sektorze JEDEN element, nic poza tym. Numeracja: rzędami od lewej do prawej, od góry.")
	l.append("SKALA: w całym arkuszu 1 m rzeczywistej ściany = %d px. Rozmiary elementów w pikselach podano niżej – trzymaj się ich dokładnie, nie dopasowuj elementów do sektora." % ppm)
	var gable_h := wall_h + (roof_h if roof_kind == "gable" else 0.0)
	l.append(_wall_line("S1", "ściana długa A (frontowa, ze wszystkimi drzwiami i oknami widocznymi na zdjęciach)", len_m, wall_h, ppm))
	l.append(_wall_line("S2", "ściana długa B (przeciwna do S1; jeśli nie ma jej zdjęcia, wywnioskuj ją ze S1 według zasady 7 – nie wymyślaj nowego układu okien)", len_m, wall_h, ppm))
	var gable_extra := " Kontur ściany to prostokąt z trójkątnym szczytem dachu na górze; poza konturem tło." if roof_kind == "gable" else ""
	l.append(_wall_line("S3", "ściana szczytowa A", wid_m, gable_h, ppm, gable_extra))
	l.append(_wall_line("S4", "ściana szczytowa B", wid_m, gable_h, ppm, gable_extra))
	var slope := _slope(info)
	l.append("- S5 – dach: jedna połać pokrycia dachowego widziana wprost z góry, %.1f m wzdłuż kalenicy × %.1f m w dół połaci, czyli %d × %d px; bez kalenicy, bez komina, bez cieni." % [len_m, slope, int(round(len_m * ppm)), int(round(slope * ppm))])
	var idx := 6
	for a in annexes:
		if idx > 8:
			break
		l.append(_wall_line("S%d" % idx, "ściana dobudówki", float(a.get("len", 4.0)), float(a.get("wall_h", 3.0)), ppm))
		idx += 1
	while idx <= 8:
		l.append("- S%d – zostaw puste (samo tło)." % idx)
		idx += 1
	l.append("")
	l.append("ZASADA NADRZĘDNA – to jest fototekstura, nie rysunek")
	l.append("Jeśli na zdjęciu widać CAŁĄ ścianę, POPRAW tę ścianę, zamiast rysować nową: wyprostuj perspektywę, usuń to, co ją zasłania (patrz zasada 4), uzupełnij braki. Okna, drzwi, ich LICZBA i ROZSTAW, kolory, gzymsy, pęknięcia i zabrudzenia mają zostać dokładnie takie, jakie są na zdjęciu. Nie dodawaj okien, nie usuwaj ich i nie przestawiaj. Wymyślaj wyłącznie tam, gdzie zdjęcia ściany brakuje.")
	l.append("")
	l.append("KROK 0 – SPIS PRZED RYSOWANIEM (napisz go tekstem, zanim wygenerujesz obraz)")
	l.append("Dla każdego zdjęcia podaj: którą ścianę przedstawia (S1…), ile kondygnacji, ile okien w każdym rzędzie (np. „2 rzędy po 4 okna”), ile drzwi, jakie gzymsy, pasy, cokół, ozdoby. Potem rysuj tak, żeby arkusz się z tym spisem zgadzał. Jeśli nie umiesz zachować liczby lub rozstawu okien, napisz to wprost zamiast cicho je zmieniać.")
	l.append("")
	l.append("ZASADY")
	l.append("1. Każdy element to płaskie, frontalne zdjęcie bez perspektywy (jakby zrobione teleobiektywem na wprost, krawędzie pionowe i poziome), bez zbieżności linii.")
	l.append("2. Zachowaj dokładnie podane rozmiary i proporcje – nie rozciągaj ani nie ściskaj. Skala jest jedna dla całego arkusza: te same okna i cegły mają ten sam rozmiar na wszystkich ścianach.")
	l.append("3. Tło poza elementami: jednolity neutralny szary (#808080), bez gradientu, bez cienia. Między elementem a krawędzią sektora zostaw co najmniej 16 px tła.")
	l.append("4. Usuń z elementów: niebo, trawę, ludzi, samochody, drzewa, rynny z cieniem, krzaki przed ścianą, napisy i znaki wodne. Uzupełnij tynk/cegłę tam, gdzie coś zasłaniało. Zostaw okna, drzwi, gzyms, cokół i podobne elementy ściany – nie wydzielaj ich osobno.")
	l.append("5. Nie dodawaj żadnych opisów, ramek, numerów sektorów ani legendy na obrazie.")
	l.append("5a. Ściana kończy się na linii okapu: bez paska dachu, bez dachówek, bez nieba nad nią. Cokół i fundament zostają. Szczyt (S3, S4) kończy się na krawędzi dachu.")
	l.append("6. Dach: sama faktura pokrycia, powtarzalna, równomierna, bez śladów kalenicy i krawędzi.")
	l.append("7. Jeśli na zdjęciach brakuje jakiejś ściany, wywnioskuj ją ze stylu pozostałych, ale TYLKO materiał, kolor i ogólny charakter; nie wymyślaj dekoracji, tynków „w łatach”, rzeźb ani dziwnych plam. Okna dodaj tam, gdzie wynikają z reszty budynku, i oznacz sektor w JSON jako „inferred”. Nie zostawiaj pustego sektora, chyba że opisano go jako pusty.")
	var used: Array = []
	for e in elements(info):
		used.append(e[0])
	l.append("8. Odpowiedź ma CZTERY części w tej kolejności: (0) spis przed rysowaniem, (1) obraz arkusza, (2) krótka lista odstępstw od zdjęć (albo „brak”), (3) opis JSON tego obrazu (niżej). Wszystko w jednej wiadomości.")
	l.append(GptDescribe.prompt_section(used))
	return "\n".join(l)
